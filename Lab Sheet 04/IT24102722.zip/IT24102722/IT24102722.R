setwd("C:\\Users\\it24102722\\Desktop\\IT24102722")
branch_data <- read.csv("Exercise.txt", header= TRUE)
head(branch_data)

str(branch_data)

boxplot(branch_data$Sales_X1, main ="sales Distribution",outliine ="sales") 

summary(branch_data$Advertising_X2)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)
